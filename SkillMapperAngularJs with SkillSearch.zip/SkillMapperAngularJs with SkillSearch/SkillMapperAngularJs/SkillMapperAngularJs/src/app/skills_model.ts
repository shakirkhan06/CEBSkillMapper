export class Skills
 {
 //public skillId:number;
  public employeeid:number;
   public skillName:string;
   public certifications:string;
  public studentsTrained:number;
  public teachingHrs:number;
  public studentPlaced:number;
     
}