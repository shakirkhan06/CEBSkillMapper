import { Component, OnInit,Input } from '@angular/core';
import{Skills} from '../skills_model'
import{SkillsService} from '../skills.service';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

import { Observable, Subject } from 'rxjs';

import {
   debounceTime, distinctUntilChanged, switchMap
 } from 'rxjs/operators';

@Component({
  selector: 'app-searchskills',
  templateUrl: './searchskills.component.html',
  styleUrls: ['./searchskills.component.css']
})
export class SearchskillsComponent implements OnInit {

  @Input() skills: Skills;
 skillv$: Observable<Skills[]>;
 private searchTerms = new Subject<string>();


 constructor(private route: ActivatedRoute,private skillsserve :SkillsService) { }


// Push a search term into the observable stream.
 search(term: string): void {
   this.searchTerms.next(term);
 }
 
 getAll(): void {
  const employeeid = +this.route.snapshot.paramMap.get('employeeid');
  this.skillsserve.getid(employeeid)
  .subscribe(skills => this.skills = skills);
}

 ngOnInit(): void {
   this.skillv$ = this.searchTerms.pipe(
     // wait 300ms after each keystroke before considering the term
     debounceTime(300),

     // ignore new term if same as previous term
     distinctUntilChanged(),

     // switch to new search observable each time the term changes
     switchMap((term: string) => this.skillsserve.searchSkills(term)),
   );
 }

}
