import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchskillsComponent } from './searchskills.component';

describe('SearchskillsComponent', () => {
  let component: SearchskillsComponent;
  let fixture: ComponentFixture<SearchskillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchskillsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchskillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
