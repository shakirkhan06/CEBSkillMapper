import { Component, OnInit } from '@angular/core';
import{EmployeeService}from '../employee.service';
import {Employee}from '../employee_model'
import{EMPLOYEES} from '../employee_listconstant';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  emp: Employee;

  empl:Employee[];


  constructor(private employeeservice:EmployeeService) { }

  ngOnInit() {
    this.getAll();
  
  }
  getAll(): void {
    this.employeeservice.getAll().subscribe(empl => this.empl = empl);
  }
}
