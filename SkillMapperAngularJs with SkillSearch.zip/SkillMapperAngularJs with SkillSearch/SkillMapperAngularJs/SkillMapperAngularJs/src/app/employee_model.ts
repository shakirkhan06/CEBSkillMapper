export class Employee
 {
   public employeeid:number;
   public employeename:string;
   public email:string;
   public pass:string;
   public age:number;
   public mobile:string;
   public gender:string;
   public qualification:string;
     
}