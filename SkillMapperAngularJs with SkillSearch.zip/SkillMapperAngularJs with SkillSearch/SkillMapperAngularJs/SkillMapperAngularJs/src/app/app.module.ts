import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeService } from './employee.service';
import { SkillsService } from './skills.service'
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './/app-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { SkillsComponent } from './skills/skills.component';
import { SkillsDetailsComponent } from './skills-details/skills-details.component';
import { SearchskillsComponent } from './searchskills/searchskills.component';

@NgModule({
  declarations: [
    AppComponent, 
    EmployeeComponent,
    DashboardComponent,
    EmployeeDetailsComponent,
    SkillsComponent,
    SkillsDetailsComponent,
    SearchskillsComponent
  ],
  imports: [
    BrowserModule,
      FormsModule,
       HttpClientModule,
       AppRoutingModule
  ],
  providers: [EmployeeService,SkillsService],
  bootstrap: [AppComponent]
})


export class AppModule { }
