import { Component, OnInit } from '@angular/core';
import{EmployeeService}from '../employee.service';
import {Employee}from '../employee_model'


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {


  //employee: Employee[] = [];
  //constructor(private employeeserv : EmployeeService) { }

  ngOnInit() {
    //this.getAll();
  }
/*getAll(): void {
    this.employeeserv.getAll()
      .subscribe(employee => this.employee = employee.slice(1, 5));
  }*/
}
