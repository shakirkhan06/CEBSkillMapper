import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SkillsComponent } from './skills/skills.component';
import { EmployeeComponent } from'./employee/employee.component';
import { DashboardComponent }   from './dashboard/dashboard.component';
import { EmployeeDetailsComponent }  from './employee-details/employee-details.component';
import {SkillsDetailsComponent} from './skills-details/skills-details.component'

const routes: Routes = [
  //{path:'',component :EmployeeDetailsComponent},//component path--
  //{ path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'employeedetails', component: EmployeeDetailsComponent },
  { path: 'employee', component: EmployeeComponent },
  { path: 'detail/:employeeid', component: EmployeeDetailsComponent},
  { path: 'skills', component: SkillsComponent},
  { path: 'SkillsDetailsComponent',component:SkillsDetailsComponent},
  { path: 'details/:employeeid', component: SkillsDetailsComponent}
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
