import {Employee} from './employee_model';

export const EMPLOYEES: Employee[] = [
  { employeeid:501,employeename:'Shakir',email:'shakir@gmail.com',pass:'khan123',age:35,mobile:'9500839240',gender:'Male',qualification:'Msc' },
  { employeeid:502,employeename:'Saleem',email:'saleem@gmail.com',pass:'khan123',age:29,mobile:'9443540705',gender:'Male',qualification:'ECE' }
];