import { Component, OnInit } from '@angular/core';
import{Skills} from '../skills_model'

import{SkillsService} from '../skills.service'


@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.css']
})
export class SkillsComponent implements OnInit {


 empl: Skills;
 skillv:Skills[];

 constructor(private skillsserve:SkillsService) { }

 ngOnInit() 
 {
   this.getAll();
 }

getAll(): void {
  this.skillsserve.getAlls().subscribe(skillv => this.skillv = skillv);
}

add(employeeid:number,skillName:string,certifications:string,studentsTrained:number,studentPlaced:number,teachingHrs:number ): void 
{
   // employeename=employeename;
   //emp.employeeid=employeeid;
   this.empl=new Skills();
   if(employeeid!=0)
   {
 // this.empl.skillId=skillId;
  this.empl.employeeid=employeeid;
  this.empl.skillName=skillName;
  this.empl.certifications=certifications;
  this.empl.studentsTrained=studentsTrained;
  this.empl.studentPlaced=studentPlaced;
  this.empl.teachingHrs=teachingHrs;
  


  
    this.skillsserve.addservice(this.empl)
      .subscribe(employee => {
        this.skillv.push(this.empl);
      });
   }
  }
  delete(skills:Skills): void {
 
    this.skillv = this.skillv.filter(h => h !== skills);
      this.skillsserve.deleteSkill(skills).subscribe();
  }
   



}
