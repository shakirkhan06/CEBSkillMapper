import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Employee } from './employee_model';
import { EMPLOYEES } from './employee_listconstant';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})


export class EmployeeService {
private strUrl ='http://localhost:8045/CEBSkillMapperRestFEnd/api/emp';  // URL to web api
//private strUrl='api/employee';
//get all list 
getAll(): Observable<Employee[]> {
  //return of(EMPLOYEES);
  return this.http.get<Employee[]>(this.strUrl) 
}
/** POST: add a new employee to the server */
  addservice (employee: Employee): Observable<Employee> {//observable data services is an angular injectale server
    return this.http.post<Employee>(this.strUrl, employee, httpOptions); 
  }
  deleteService (employee: Employee | number): Observable<Employee> {
    //const url='http://localhost:8701/CEBSkillMapperRestFEnd/api/emp/'+employee;
    const id = typeof employee === 'number' ? employee : employee.employeeid;
    const url = `${this.strUrl}/${id}`;

    return this.http.delete<Employee>(url, httpOptions)
  }
  updateEmployee (employee:Employee): Observable<any> {
    return this.http.put(this.strUrl,employee, httpOptions);
    
  }
   getid(employeeid: number): Observable<Employee> {
    const url = `${this.strUrl}/${employeeid}`;
    return this.http.get<Employee>(url);
  }
  constructor(private http: HttpClient) { }
}
